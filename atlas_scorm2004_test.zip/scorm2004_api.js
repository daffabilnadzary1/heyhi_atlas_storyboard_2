/* Minimal SCORM 2004 run-time wrapper.
   Finds the LMS-provided window.API_1484_11 object, then exposes a few helpers.
   Dependency-free so it runs inside any LMS iframe. */

(function (global) {
  "use strict";

  var API = null;
  var initialised = false;
  var listeners = [];

  function log(msg) {
    listeners.forEach(function (fn) { fn(msg); });
    if (global.console) { console.log("[SCORM 2004] " + msg); }
  }

  function findAPIIn(win) {
    var tries = 0;
    while (win.API_1484_11 == null && win.parent != null && win.parent != win && tries < 500) {
      tries++;
      win = win.parent;
    }
    return win.API_1484_11;
  }

  function locateAPI() {
    var api = findAPIIn(global);
    if (api == null && global.opener != null) {
      api = findAPIIn(global.opener);
    }
    return api;
  }

  var Scorm = {
    onLog: function (fn) { listeners.push(fn); },

    init: function () {
      API = locateAPI();
      if (API == null) {
        log("FAIL: no SCORM 2004 API (API_1484_11) found in any parent or opener window.");
        return false;
      }
      log("API_1484_11 located.");
      var ok = API.Initialize("");
      log("Initialize -> " + ok);
      if (ok !== "true") {
        var e = API.GetLastError();
        log("GetLastError -> " + e + " " + API.GetErrorString(e));
        return false;
      }
      initialised = true;
      return true;
    },

    get: function (key) {
      if (!initialised) { return "(not initialised)"; }
      var v = API.GetValue(key);
      log("GET " + key + " -> \"" + v + "\"");
      return v;
    },

    set: function (key, value) {
      if (!initialised) { log("SET ignored, not initialised."); return false; }
      var ok = API.SetValue(key, String(value));
      log("SET " + key + " = \"" + value + "\" -> " + ok);
      if (ok !== "true") {
        var e = API.GetLastError();
        log("  error " + e + ": " + API.GetErrorString(e) + " / " + API.GetDiagnostic(e));
      }
      return ok === "true";
    },

    commit: function () {
      if (!initialised) { return false; }
      var ok = API.Commit("");
      log("Commit -> " + ok);
      return ok === "true";
    },

    finish: function () {
      if (!initialised) { return false; }
      var ok = API.Terminate("");
      log("Terminate -> " + ok);
      initialised = false;
      return ok === "true";
    },

    isReady: function () { return initialised; }
  };

  global.Scorm = Scorm;
})(window);
