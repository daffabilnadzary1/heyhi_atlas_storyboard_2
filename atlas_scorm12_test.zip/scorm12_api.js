/* Minimal SCORM 1.2 run-time wrapper.
   Finds the LMS-provided window.API object, then exposes a few helpers.
   Deliberately dependency-free so it runs inside any LMS iframe. */

(function (global) {
  "use strict";

  var API = null;
  var initialised = false;
  var listeners = [];

  function log(msg) {
    listeners.forEach(function (fn) { fn(msg); });
    if (global.console) { console.log("[SCORM 1.2] " + msg); }
  }

  function findAPIIn(win) {
    var tries = 0;
    while (win.API == null && win.parent != null && win.parent != win && tries < 500) {
      tries++;
      win = win.parent;
    }
    return win.API;
  }

  function locateAPI() {
    var api = findAPIIn(global);
    if (api == null && global.opener != null) {
      api = findAPIIn(global.opener);
    }
    return api;
  }

  var Scorm = {
    onLog: function (fn) { listeners.push(fn); },

    init: function () {
      API = locateAPI();
      if (API == null) {
        log("FAIL: no SCORM 1.2 API found in any parent or opener window.");
        return false;
      }
      log("API located.");
      var ok = API.LMSInitialize("");
      log("LMSInitialize -> " + ok);
      if (ok !== "true") {
        log("LMSGetLastError -> " + API.LMSGetLastError() + " " + API.LMSGetErrorString(API.LMSGetLastError()));
        return false;
      }
      initialised = true;
      return true;
    },

    get: function (key) {
      if (!initialised) { return "(not initialised)"; }
      var v = API.LMSGetValue(key);
      log("GET " + key + " -> \"" + v + "\"");
      return v;
    },

    set: function (key, value) {
      if (!initialised) { log("SET ignored, not initialised."); return false; }
      var ok = API.LMSSetValue(key, String(value));
      log("SET " + key + " = \"" + value + "\" -> " + ok);
      if (ok !== "true") {
        var e = API.LMSGetLastError();
        log("  error " + e + ": " + API.LMSGetErrorString(e) + " / " + API.LMSGetDiagnostic(e));
      }
      return ok === "true";
    },

    commit: function () {
      if (!initialised) { return false; }
      var ok = API.LMSCommit("");
      log("LMSCommit -> " + ok);
      return ok === "true";
    },

    finish: function () {
      if (!initialised) { return false; }
      var ok = API.LMSFinish("");
      log("LMSFinish -> " + ok);
      initialised = false;
      return ok === "true";
    },

    isReady: function () { return initialised; }
  };

  global.Scorm = Scorm;
})(window);
